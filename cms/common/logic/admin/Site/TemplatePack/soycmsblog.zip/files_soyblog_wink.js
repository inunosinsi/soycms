//jquery
document.write('<scrip' + 't type="text/javascript" src="http://www.google.com/jsapi"><' + '/script>');
document.write('<scrip' + 't type="text/javascript">google.load("jquery", "1.2.6");<' + '/script>');


window.onload = function(){
	$("img.wink").hover(function(){
		$(this).css("opacity", "0.2");
		$(this).css("filter", "alpha(opacity=20)");
		$(this).fadeTo("slow", 1.0);
	});
	$("input.wink").hover(function(){
		$(this).css("opacity", "0.2");
		$(this).css("filter", "alpha(opacity=20)");
		$(this).fadeTo("slow", 1.0);
	});
	
};

