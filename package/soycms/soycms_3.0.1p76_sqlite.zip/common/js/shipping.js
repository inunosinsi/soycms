var freeArea = document.querySelector("#free_shipping_notice");
var noFreeArea = document.querySelector("#no_free_shipping_notice");

(function(){
	checkFreeShipping();
	setInterval(checkFreeShipping, 2000);
})();

function checkFreeShipping(){
	if(freeArea && noFreeArea){
		xhr = new XMLHttpRequest();
		xhr.open("GET", "https://www.cannana.jp/decision");
		xhr.send();			
		xhr.addEventListener("load", function(){
			var resp = xhr.response;
			if(resp){
				var res = JSON.parse(resp);
				if(res.free > 0){
					freeArea.style.display = "inline";
					noFreeArea.style.display = "none";
				}else{
					freeArea.style.display = "none";
					noFreeArea.style.display = "inline";
				}
			}
		});
	}
}