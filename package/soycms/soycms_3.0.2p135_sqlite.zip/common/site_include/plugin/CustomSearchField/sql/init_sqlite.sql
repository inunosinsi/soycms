CREATE TABLE EntryCustomSearch (
	entry_id INTEGER NOT NULL UNIQUE
);
