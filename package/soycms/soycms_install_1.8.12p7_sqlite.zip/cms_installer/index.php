<?php
$_SERVER["SCRIPT_FILENAME"] = dirname($_SERVER["SCRIPT_FILENAME"])."/installer.php";
include_once("installer.php");
?>
