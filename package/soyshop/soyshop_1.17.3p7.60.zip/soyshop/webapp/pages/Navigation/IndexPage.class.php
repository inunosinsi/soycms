<?php 
/**
 * @class Navigation.IndexPage
 * @date 2009-11-24T15:37:20+09:00
 * @author SOY2HTMLFactory
 */ 
class IndexPage extends WebPage{
	
	function __construct(){
		WebPage::__construct();

	}
}


?>