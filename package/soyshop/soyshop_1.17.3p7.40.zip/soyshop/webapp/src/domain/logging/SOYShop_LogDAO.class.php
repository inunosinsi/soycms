<?php
/**
 * @entity logging.SOYShop_Log
 */
abstract class SOYShop_LogDAO extends SOY2DAO{

}
?>