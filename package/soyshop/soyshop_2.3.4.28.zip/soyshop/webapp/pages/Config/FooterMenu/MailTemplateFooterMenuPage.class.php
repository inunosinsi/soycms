<?php

class MailTemplateFooterMenuPage extends HTMLPage{

	function __construct(){
		parent::__construct();
	}
}
