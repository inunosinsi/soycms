<?php

class ItemCustomfieldFooterMenuPage extends HTMLPage{

	function __construct(){
		parent::__construct();
	}
}
