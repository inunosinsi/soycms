<?php

class DefaultMenuPage extends HTMLPage{

	function DefaultMenuPage(){
		HTMLPage::HTMLPage();
	}

}

?>