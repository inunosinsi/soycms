<?php

class TopPageSubMenu extends HTMLPage{

    function TopPageSubMenu() {
		HTMLPage::HTMLPage();
    }
}
?>