<?php
include_once(dirname(dirname(__FILE__)) . "/common/common.php");
class SOYShopPaypalPaymentOptionPage extends WebPage{

	private $order;
	private $cart;
	private $isMobile = false;

	function __construct(){
		$this->isMobile = defined("SOYSHOP_IS_MOBILE");
		parent::__construct();
	}

	function doPost(){
	}

	function execute(){

		$user = soyshop_get_user_object($this->order->getUserId());
		$config = PayPalCommon::getPaypalConfig();

		$paypal_url = ($config["sandbox"] == 1) ? "https://www.sandbox.paypal.com/cgi-bin/webscr" : "https://www.paypal.com/cgi-bin/webscr";
		$paypal_mail = ($config["sandbox"] == 1) ? $config["test_mailaddress"] : $config["mailaddress"];
		$paypal_item_name = $config["item_name"];
		$paypal_code = "JPY";	//日本円
		$paypal_charset = (isset($config["charset"])) ? $config["charset"] : "Shift-JIS";

		$paypal_return_url = soyshop_get_cart_url(false,true);
		$paypal_cancel_return_url = soyshop_get_cart_url(false,true) . "?cancel=1";
		$paypal_notification_url = soyshop_get_cart_url(false,true) . "?soyshop_notification=payment_paypal";

		//クッキー非対応機種対策
		$param = null;
		if(isset($_GET[session_name()])){
			$param = session_name() . "=" . session_id();
			$paypal_return_url = $paypal_return_url . "&" . $param;
			$paypal_cancel_return_url = $paypal_cancel_return_url . "&" . $param;
			$paypal_notification_url = $paypal_notification_url . "&" . $param;
		}

		$order = soyshop_get_order_object($this->cart->getAttribute("order_id"));

		$paypal_item_amount = $order->getPrice();
		$paypal_item_number = $order->getTrackingNumber();//商品番号＝TrackingNumber
		$trackingNumber = $order->getTrackingNumber();


		$this->addForm("form", array(
			"method" => "post",
			"action" => $paypal_url,
			"attr:accept-charset" => $paypal_charset
		));

		$this->addInput("business", array(
			"name" => "business",
			"value" => $paypal_mail
		));

		$this->addInput("currency_code", array(
			"name" => "currency_code",
			"value" => $paypal_code
		));

		$this->addInput("return", array(
			"name" => "return",
			"value" => $paypal_return_url
		));

		$this->addInput("cancel_return", array(
			"name" => "cancel_return",
			"value" => $paypal_cancel_return_url
		));

		$this->addInput("notify_url", array(
			"name" => "notify_url",
			"value" => $paypal_notification_url
		));

		$this->addInput("item_name", array(
			"name" => "item_name",
			"value" => $paypal_item_name
		));

		$this->addInput("amount", array(
			"name" => "amount",
			"value" => $paypal_item_amount
		));

		$this->addInput("item_number", array(
			"name" => "item_number",
			"value" => $paypal_item_number
		));

		$this->addInput("custom", array(
			"name" => "custom",
			"value" => $trackingNumber
		));
	}

	function getTemplateFilePath(){
		return dirname(__FILE__) . "/option.html";
	}

	function setOrder($order) {
		$this->order = $order;
	}

	function setCart($cart){
		$this->cart = $cart;
	}
}
