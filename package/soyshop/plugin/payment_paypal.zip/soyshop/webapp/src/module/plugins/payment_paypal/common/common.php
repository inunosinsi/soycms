<?php

class PayPalCommon{

	public static function getPaypalConfig(){
		SOY2::import("domain.config.SOYShop_ShopConfig");
		$shopConfig = SOYShop_ShopConfig::load();

		$companyInformation = $shopConfig->getCompanyInformation();

		return SOYShop_DataSets::get("payment_paypal.config", array(
			"sandbox" => 1,
			"test_mailaddress" => $companyInformation["mailaddress"],
			"mailaddress" => "@",
			"charset" => "Shift-JIS",
			"item_name" => $shopConfig->getShopName() . " 商品購入代金"

		));
	}
}
