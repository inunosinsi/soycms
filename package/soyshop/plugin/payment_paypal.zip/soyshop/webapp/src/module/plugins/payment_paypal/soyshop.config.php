<?php
include(dirname(__FILE__) . "/common/common.php");
class SOYShopPaypalPaymentConfig extends SOYShopConfigPageBase{

	/**
	 * @return string
	 */
	function getConfigPage(){

		$form = SOY2HTMLFactory::createInstance("SOYShopPaypalPaymentConfigFormPage");
		$form->setConfigObj($this);
		$form->execute();
		return $form->getObject();
	}

	/**
	 * @return string
	 */
	function getConfigPageTitle(){
		return "PayPalの設定";
	}

	function getDescription(){
		return "";
	}
}
SOYShopPlugin::extension("soyshop.config", "payment_paypal", "SOYShopPaypalPaymentConfig");

class SOYShopPaypalPaymentConfigFormPage extends WebPage{

	function __construct(){
		SOY2DAOFactory::importEntity("SOYShop_DataSets");
	}

	function doPost(){
		SOY2DAOFactory::importEntity("SOYShop_DataSets");

		if(isset($_POST["config"])){
			$config = $_POST["config"];

			$config["sandbox"] = (isset($config["sandbox"])) ? (int)$config["sandbox"] : 0;

			SOYShop_DataSets::put("payment_paypal.config", $config);
			SOY2PageController::jump("Config.Detail?plugin=payment_paypal&updated");
		}
	}

	function execute(){

		$config = PayPalCommon::getPaypalConfig();

		parent::__construct();

		$this->addForm("form");

		$this->addCheckBox("sandbox", array(
			"name" => "config[sandbox]",
			"value" => 1,
			"selected" => $config["sandbox"] ==1,
			"elementId"	=> "config_sandbox"
		));

		$this->addInput("test_mailaddress", array(
			"name" => "config[test_mailaddress]",
			"value" => $config["test_mailaddress"]
		));

		$this->addInput("mailaddress", array(
			"name" => "config[mailaddress]",
			"value" => $config["mailaddress"]
		));

		$this->addInput("charset", array(
			"name" => "config[charset]",
			"value" => $config["charset"]
		));

		$this->addInput("item_name", array(
			"name" => "config[item_name]",
			"value" => $config["item_name"]
		));
	}

	function getTemplateFilePath(){
		return dirname(__FILE__) . "/soyshop.config.html";
	}

	function setConfigObj($obj) {
		$this->config = $obj;
	}
}
