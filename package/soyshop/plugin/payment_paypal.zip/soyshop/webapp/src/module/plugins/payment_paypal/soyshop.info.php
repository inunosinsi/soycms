<?php
/*
 */
class SOYShopPaypalPaymentModuleInfo extends SOYShopInfoPageBase{

	function getPage($active = false){
		if($active){
			return '<a href="' . SOY2PageController::createLink("Config.Detail?plugin=payment_paypal") . '">PayPal支払いモジュールの設定画面へ</a>';
		}else{
			return "";
		}
	}
}
SOYShopPlugin::extension("soyshop.info", "payment_paypal", "SOYShopPaypalPaymentModuleInfo");
