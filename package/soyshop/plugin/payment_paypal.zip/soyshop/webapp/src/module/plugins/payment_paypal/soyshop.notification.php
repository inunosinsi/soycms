<?php
class PaymentPaypal_SOYShopNotification extends SOYShopNotification{

	function execute(){

		if(isset($_POST["custom"])){
			$orderDAO = SOY2DAOFactory::create("order.SOYShop_OrderDAO");
			try{
				$order = $orderDAO->getByTrackingNumber($_POST["custom"]);
			}catch(Exception $e){
				$order = new SOYShop_Order();
			}

			if(is_numeric($order->getId())){
				//取引IDを記録
		    	$order->setAttribute("payment_paypal.email", array(
		    		"name" => "PayPal利用者(email)",
		    		"value" => $_POST["payer_email"],
		    		"readonly" => true,
			    	"hidden" => true
		    	));
				$order->setAttribute("payment_paypal.name", array(
					"name" => "PayPal利用者名",
					"value" => $_POST["first_name"] ." " . $_POST["last_name"],
					"readonly" => true,
			    	"hidden" => true
				));
		    	$order->setAttribute("payment_paypal.txn_id", array(
		    		"name" => "PayPal取引ID",
		    		"value" => $_POST["txn_id"],
		    		"readonly" => true,
			    	"hidden" => true
		    	));
		    	$order->setAttribute("payment_paypal.mc_gross", array(
		    		"name" => "PayPal取引金額",
		    		"value" => $_POST["mc_gross"],
		    		"readonly" => true,
			    	"hidden" => true
		    	));

				//支払いステータスを済みに設定
				$order->setPaymentStatus(SOYShop_Order::PAYMENT_STATUS_CONFIRMED);
				$orderDAO->updateStatus($order);

				//CartLogicを使ってメールを送信
				$user = soyshop_get_user_object($order->getUserId());

				SOY2::import("logic.cart.CartLogic");
				$cart = new CartLogic();
				$cart->setAttribute("order_id", $order->getId());
				$cart->setCustomerInformation($user);
				$cart->orderComplete();
			}
		}
	}
}
SOYShopPlugin::extension("soyshop.notification", "payment_paypal", "PaymentPaypal_SOYShopNotification");
