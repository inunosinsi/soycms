<?php
class SOYShopPaypalPaymentModule extends SOYShopPayment{

	function onSelect(CartLogic $cart){
		$module = new SOYShop_ItemModule();
		$module->setId("payment_paypal");
		$module->setType("payment_module");//typeを指定しておくといいことがある
		$module->setName("PayPal");
		$module->setPrice(0);
		$module->setIsVisible(false);

		$cart->addModule($module);

		$message = (self::_isSandbox()) ? "PayPalでのお支払い" : "PayPalでのお支払い";

		//属性の登録
		$cart->setOrderAttribute("payment_paypal", "支払方法", $message);
	}

	function getName(){
		return (self::_isSandbox()) ? "PayPal支払い" : "PayPal支払い";
	}

	function getDescription(){
		$message = (self::_isSandbox()) ? "PayPalで支払います。" : "PayPalで支払います。";
		return SOYShop_DataSets::get("payment_paypal.description", $message);
	}

	function hasOptionPage(){
		return true;
	}

	function getOptionPage(){

		//cancel
		if(isset($_GET["cancel"])){
			$this->getCart()->setAttribute("page", "Cart04");
			soyshop_redirect_cart();
			exit;
		}

		//if completed
		$order = soyshop_get_order_object($this->getCart()->getAttribute("order_id"));
	    if($order->getStatus() >= SOYShop_Order::ORDER_STATUS_REGISTERED){
			$this->getCart()->setAttribute("page", "Complete");
			soyshop_redirect_cart();
			exit;
	    }

		//出力
		require_once(dirname(__FILE__) . "/option/SOYShopPaypalPaymentOptionPage.class.php");
		$form = SOY2HTMLFactory::createInstance("SOYShopPaypalPaymentOptionPage");
		$form->setOrder($order);
		$form->setCart($this->getCart());
		$form->execute();
		echo $form->getObject();
	}

	function onPostOptionPage(){

		//finishの場合
		if(isset($_POST["payment_status"]) && $_POST["payment_status"] == "Completed"){
			//支払い状況を更新する
			$orderDAO = SOY2DAOFactory::create("order.SOYShop_OrderDAO");
			$order = soyshop_get_order_object($this->getCart()->getAttribute("order_id"));

	    	//取引IDを記録
	    	$order->setAttribute("payment_paypal.email", array(
	    		"name" => "PayPal利用者(email)",
	    		"value" => $_POST["payer_email"],
	    		"readonly" => true,
	    		"hidden" => true
	    	));
			$order->setAttribute("payment_paypal.name", array(
				"name" => "PayPal利用者名",
				"value" => $_POST["first_name"] . " " . $_POST["last_name"],
				"readonly" => true,
	    		"hidden" => true
			));
	    	$order->setAttribute("payment_paypal.txn_id", array(
	    		"name" => "PayPal取引ID",
	    		"value" => $_POST["txn_id"],
	    		"readonly" => true,
	    		"hidden" => true
	    	));
	    	$order->setAttribute("payment_paypal.mc_gross", array(
	    		"name" => "PayPal取引金額",
	    		"value" => $_POST["mc_gross"],
	    		"readonly" => true,
	    		"hidden" => true
	    	));

			//支払いステータスを済みに設定
	    	$order->setPaymentStatus(SOYShop_Order::PAYMENT_STATUS_CONFIRMED);
			$orderDAO->updateStatus($order);

			$user = soyshop_get_user_object($order->getUserId());
			if(is_numeric($user->getId())){
				$this->getCart()->setAttribute("order_id", $order->getId());
				$this->getCart()->setCustomerInformation($user);
				$this->getCart()->orderComplete();
			}

			$this->getCart()->setAttribute("page", "Complete");
			return;
		}
	}

	private function _isSandbox(){
		static $isSandbox;
		if(is_null($isSandbox)) {
			SOY2DAOFactory::importEntity("SOYShop_DataSets");
			include_once(dirname(__FILE__) . "/common/common.php");
			$cnf = PayPalCommon::getPaypalConfig();
			$isSandbox = (isset($cnf["sandbox"]) && $cnf["sandbox"] == 1);
		}
		return $isSandbox;
	}
}

SOYShopPlugin::extension("soyshop.payment",			"payment_paypal", "SOYShopPaypalPaymentModule");
SOYShopPlugin::extension("soyshop.payment.option",	"payment_paypal", "SOYShopPaypalPaymentModule");
