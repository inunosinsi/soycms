<?php

class IndexPage extends WebPage{

    function __construct() {
		SOY2PageController::jump("Site.Pages");
    	//parent::__construct();
    }
}
