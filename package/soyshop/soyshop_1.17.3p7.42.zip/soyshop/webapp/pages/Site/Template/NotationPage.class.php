<?php
/**
 * 顧客入力項目 一覧
 */
class NotationPage extends WebPage{

	function __construct(){
		WebPage::__construct();
	}
	
}

?>