<?php

class DefaultMenuPage extends HTMLPage{

	function __construct(){
		parent::__construct();
	}

}

?>