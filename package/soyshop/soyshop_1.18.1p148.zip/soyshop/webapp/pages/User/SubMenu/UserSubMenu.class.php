<?php
/**
 * @class User.SubMenu.UserSubMenu
 * @date 2009-12-09T14:08:58+09:00
 * @author SOY2HTMLFactory
 */
class UserSubMenu extends WebPage{

	function UserSubMenu(){
		parent::__construct();

	}
}
