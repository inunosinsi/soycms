<?php

class IndexPage extends WebPage{

    function IndexPage() {
    	WebPage::WebPage();
    }
}
?>