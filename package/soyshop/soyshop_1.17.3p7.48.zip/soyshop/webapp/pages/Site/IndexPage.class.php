<?php

class IndexPage extends WebPage{

    function __construct() {
    	WebPage::__construct();
    }
}
?>