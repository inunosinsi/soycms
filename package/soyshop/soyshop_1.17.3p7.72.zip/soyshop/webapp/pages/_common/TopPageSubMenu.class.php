<?php

class TopPageSubMenu extends HTMLPage{

    function __construct() {
		HTMLPage::__construct();
    }
}
?>