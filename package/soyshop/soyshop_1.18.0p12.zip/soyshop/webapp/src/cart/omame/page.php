<?php
//言語の設定
if(!defined("SOYSHOP_LANGUAGE")) define("SOYSHOP_LANGUAGE", "jp");

//共通ロジックを使う
include_once(dirname(dirname(__FILE__)) . "/_common/page.php");
?>