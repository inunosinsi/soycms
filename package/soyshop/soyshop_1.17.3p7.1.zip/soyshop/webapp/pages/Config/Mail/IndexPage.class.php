<?php 
/**
 * @class Config.Mail.IndexPage
 * @date 2009-07-30T18:00:46+09:00
 * @author SOY2HTMLFactory
 */ 
class IndexPage extends WebPage{
	
	function IndexPage(){
		WebPage::WebPage();

	}
}


?>