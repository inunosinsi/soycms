<?php
//言語の設定
if(!defined("SOYSHOP_PUBLISH_LANGUAGE")) define("SOYSHOP_PUBLISH_LANGUAGE", "jp");

//共通ロジックを使う
include_once(dirname(dirname(__FILE__)) . "/_common/page.php");
