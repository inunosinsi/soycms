<?php
/**
 * @table soyshop_log
 */
class SOYShop_Log {

	/**
	 * @column id
	 */
    private $id;

    /**
     * @column log_date
     */
    private $date;

}
?>