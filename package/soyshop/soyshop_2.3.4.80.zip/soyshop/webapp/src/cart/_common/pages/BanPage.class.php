<?php

class BanPage extends MainCartPageBase{

	function __construct(){
		parent::__construct();
	}
}
