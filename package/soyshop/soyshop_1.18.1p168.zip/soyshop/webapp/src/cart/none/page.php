<?php
//何もしない
header("HTTP/1.0 404 Not Found");
return "";
?>