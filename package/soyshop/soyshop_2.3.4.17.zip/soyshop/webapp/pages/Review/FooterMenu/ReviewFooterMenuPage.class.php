<?php

class ReviewFooterMenuPage extends HTMLPage{

	function __construct(){
		parent::__construct();
	}
}
