<?php

class ImageLogic extends SOY2LogicBase{


}
?>