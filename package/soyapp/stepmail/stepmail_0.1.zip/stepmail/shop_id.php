<?php
define(STEPMAIL_SHOP_ID, "shop3");
?>