<?php

class JobConfigPage extends WebPage{

    function __construct() {
		//廃止
    }
}
