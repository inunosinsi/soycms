CREATE TABLE soy_mail_log(
	id INTEGER primary key AUTOINCREMENT,
	log_time integer not null,
	content VARCHAR,
	more VARCHAR
);
