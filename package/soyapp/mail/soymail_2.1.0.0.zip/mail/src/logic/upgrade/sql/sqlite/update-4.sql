CREATE TABLE soymail_soyshop_connector (
	config TEXT
);
