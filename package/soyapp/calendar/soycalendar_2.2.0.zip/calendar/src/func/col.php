<?php
/**
 * カラムの箇所のカスタマイズ用の関数のサンプル
 * 実際は下記の関数をサイトディレクトリ側に配置して、モジュールで読み込むことを検討している
 */
function soycalendar_generate_day_column(int $timestamp, array $schedules){
    return "";
}