$(document).ready(function() {	
	$(".repeat").css("display","none");
	$("#confirm").click(function(){
		$(".repeat").slideToggle("normal");
		});
	
});