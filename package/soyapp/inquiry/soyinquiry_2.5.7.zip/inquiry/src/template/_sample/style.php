table#inquiry_form{
	border-collapse:collapse;
	font-size:90%;
	border:solid 1px #999;
}
#inquiry_form table{
	border-collapse:collapse;
	margin:10px 0;
	border:solid 1px #999;
}
#inquiry_form th, #inquiry_form td{
	border:dashed 1px #bbb;
	border-style:dashed solid;
	padding:8px 10px;
	text-align:left;
	background-color:white;
}
#inquiry_form th{
	background-color:#F4F9FE;
	color:#678197;;
	font-weight:normal;
}
#inquiry_form input[type="text"]{
	border:solid 1px #bbb;
}
#inquiry_form input[type="text"]:focus{
	border:solid 1px black;
}
#inquiry_form textarea{
	border:solid 1px #bbb;
}
#inquiry_form textarea:focus{
	border:solid 1px black;
}
#inquiry_form .require th{
	font-weight:bold;
}
#inquiry_form .error_message{
	color:red;
	font-weight:bold;
}
#inquiry_form_captcha{
	margin-top:10px;
	margin-bottom:10px;
}
#inquiry_form_captcha img{
	margin-bottom:5px;
}
