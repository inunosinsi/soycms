ALTER TABLE soyinquiry_column ADD COLUMN column_id VARCHAR(512);
