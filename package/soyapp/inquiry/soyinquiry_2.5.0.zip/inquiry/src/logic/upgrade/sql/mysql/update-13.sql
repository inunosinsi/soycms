ALTER TABLE soyinquiry_entry_relation ADD COLUMN page_id INTEGER AFTER inquiry_id;
ALTER TABLE soyinquiry_entry_relation ADD COLUMN site_id INTEGER AFTER inquiry_id;
