ALTER TABLE soyinquiry_entry_relation ADD COLUMN site_id INTEGER;
ALTER TABLE soyinquiry_entry_relation ADD COLUMN page_id INTEGER;
