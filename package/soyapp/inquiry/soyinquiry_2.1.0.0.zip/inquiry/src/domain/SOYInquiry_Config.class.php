<?php
/**
 * @table soyinquiry_config
 */
class SOYInquiry_Config {

    
}
?>